/**
 * CareerGo
 *
 * App utilized to create ease of access
 * to information pertaining to an 
 * individual's career fair quest.
 */

var UI = require('ui');
//var Vector2 = require('vector2');

var main = new UI.Card({
  title: 'CareerGo!',
  subtitle: 'Keeping track of your potential employers!',
});

main.show();

Pebble.addEventListener('appmessage', function(type, payload, response)
{
  console.log("We got a response");
  console.log(type);
  
  console.log(payload);
  
  console.log(response);
});

main.on('click', 'select', function(e) {
  var companies = [
    {
      title: "Apple",
      subtitle: "Spring Intern, Full Time"
    },
    {
      title: "BMW",
      subtitle: "Spring Co-Op, Follicle Tester"
    }, 
    {
      title: "Workday",
      subtitle: "Full-Time"
    }
  ];
  var Compmenu = new UI.Menu({
    sections: [{
      title: 'GT Career Fair',
      items: companies
    }]
  });
  Compmenu.on('select', function(e) {
    var detailCard = new UI.Card({
      title: companies[e.itemIndex].title,
      subtitle: companies[e.itemIndex].subtitle,
      body: 'yo'
    });
    detailCard.show();
    console.log('Selected item #' + e.itemIndex + ' of section #' + e.sectionIndex);
    console.log('The item is titled "' + e.item.title + '"');
  });
  Compmenu.show();
});


/*
main.on('click', 'up', function(e) {
  var wind = new UI.Window({
    fullscreen: true,
  });
  var textfield = new UI.Text({
    position: new Vector2(0, 65),
    size: new Vector2(144, 30),
    font: 'gothic-24-bold',
    text: 'Text Anywhere!',
    textAlign: 'center'
  });
  wind.add(textfield);
  wind.show();
});

main.on('click', 'down', function(e) {
  var card = new UI.Card();
  card.title('A Card');
  card.subtitle('Is a Window');
  card.body('The simplest window type in Pebble.js.');
  card.show();
});*/
