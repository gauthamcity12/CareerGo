void show_gui(void);
void hide_gui(void);
